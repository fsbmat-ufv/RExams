# 161.122 Statistics

This repository holds lecture slides, workshops, quizzes and data for Modules A and C of the course 161.122 Statistics at Massey University.
