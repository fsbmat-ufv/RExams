https://opendata-nzta.opendata.arcgis.com/datasets/tms-daily-traffic-counts-csv

